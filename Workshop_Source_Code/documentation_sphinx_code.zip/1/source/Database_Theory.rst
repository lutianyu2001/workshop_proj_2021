
***************
Database Theory
***************

ER Diagram
==========

.. image:: images/er_diag_6.png
    :scale: 100%
    :align: center


Functional Dependencies
=======================

.. image:: images/fd_pic_7.jpg
    :scale: 100%
    :align: center
