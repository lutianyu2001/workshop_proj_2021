.. documentation master file, created by
   sphinx-quickstart on Thu Mar  4 09:36:36 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Football Data Integrated System Documentation!
=========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   Project_Description
   Data_Description
   Data_Process
   Database_Theory
   Website_Application
   Difficulty


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
